package com.example.donor_1

data class Donation(val foodType: String, val quantity: Int, val expirationDate: String, val pickupLocation: String)
